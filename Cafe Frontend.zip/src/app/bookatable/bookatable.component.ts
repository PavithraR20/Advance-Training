import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';



@Component({
  selector: 'app-bookatable',
  templateUrl: './bookatable.component.html',
  styleUrls: ['./bookatable.component.css']
})
export class BookatableComponent implements OnInit {

  booking: BookingEntity = {
    name: '',
    email: '',
    phoneNumber: '',
    bookingDate: new Date(), 
    numberOfPeople: '',
    tableChoice: '',
    message: ''
  };

  constructor(private http: HttpClient, private datePipe: DatePipe) { }

  ngOnInit(): void {
  }

  submitForm(): void {
    const formattedDate = this.datePipe.transform(this.booking.bookingDate, 'yyyy-MM-ddTHH:mm:00.000Z');

    if (formattedDate) {
      this.booking.bookingDate = new Date(formattedDate);
    } else {
     
      console.error('Date is not in the correct format.');
    }
    
    this.http.post('http://localhost:11000/api/booking', this.booking, { responseType: 'text' })
      .subscribe(
        (response) => {
          console.log('Booking created:', response);
          
          this.clearForm();
         
          window.alert('Booking done');
        },
        (error) => {
          console.error('Error creating booking:', error.error);
          
          window.alert('Booking failed');
        }
      );
  }

  private clearForm(): void {
    this.booking = {
      name: '',
      email: '',
      phoneNumber: '',
      bookingDate: new Date(), 
      numberOfPeople: '',
      tableChoice: '',
      message: ''
    };
  }
}

interface BookingEntity {
  name: string;
  email: string;
  phoneNumber: string;
  bookingDate: Date; 
  numberOfPeople: string;
  tableChoice: string;
  message: string;
}
